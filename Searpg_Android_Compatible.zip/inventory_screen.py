import tkinter as tk
from player import save_player

def show_inventory(player):
    inv = tk.Toplevel()
    inv.title("Envanter")
    inv.geometry("300x300")

    tk.Label(inv, text="Statlar").pack()
    for stat, val in player.stats.items():
        tk.Label(inv, text=f"{stat}: {val}").pack()

    tk.Label(inv, text="Envanter").pack()
    for item in player.inventory:
        tk.Label(inv, text=item).pack()

    tk.Button(inv, text="Kaydet", command=lambda: save_player(player)).pack(pady=10)