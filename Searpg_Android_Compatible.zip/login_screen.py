import tkinter as tk
from character_select import show_character_select

def show_login_screen():
    window = tk.Tk()
    window.title("Searpg - Giriş")
    window.geometry("360x640")

    tk.Label(window, text="Searpg'e Hoşgeldiniz", font=('Helvetica', 16)).pack(pady=30)

    def start_game():
        window.destroy()
        show_character_select()

    tk.Button(window, text="Oyuna Başla", command=start_game, height=2, width=20).pack(pady=20)
    window.mainloop()