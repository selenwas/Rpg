import random

def generate_loot():
    items = ["Kılıç", "Zırh", "Kolye", "Kask"]
    effects = ["+10 STR", "+5 HP", "+3 VIT", "+2 DEX"]
    return f"{random.choice(items)} ({random.choice(effects)})"