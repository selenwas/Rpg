import tkinter as tk
from inventory_screen import show_inventory
from battle import start_battle

def show_town(player):
    town = tk.Tk()
    town.title("Kasaba")
    town.geometry("300x300")

    label = tk.Label(town, text=f"{player.name} ile Kasabadasınız")
    label.pack(pady=10)

    def on_key(event):
        key = event.keysym
        if key == "1":
            town.destroy()
            start_battle(player)
        elif key == "2":
            show_inventory(player)
        elif key == "Escape":
            town.destroy()

    town.bind("<Key>", on_key)

    tk.Label(town, text="1 - Savaş Alanı").pack(pady=5)
    tk.Label(town, text="2 - Envanter").pack(pady=5)
    tk.Label(town, text="ESC - Çıkış").pack(pady=5)

    town.focus_set()
    town.mainloop()