import tkinter as tk
import random
from items import generate_loot

def start_battle(player):
    win = tk.Tk()
    win.title("Savaş")
    win.geometry("300x200")

    enemy_hp = 50 + random.randint(0, 50)

    status = tk.Label(win, text="Bir düşmanla karşılaştınız!")
    status.pack()

    def attack(event=None):
        nonlocal enemy_hp
        damage = player.stats.get("STR", 5)
        enemy_hp -= damage
        if enemy_hp <= 0:
            loot = generate_loot()
            player.inventory.append(loot)
            status.config(text=f"Düşmanı yendiniz! Eşya: {loot}")
        else:
            status.config(text=f"{damage} hasar verdiniz. Kalan: {enemy_hp}")

    win.bind("<space>", attack)
    tk.Label(win, text="Saldırmak için Boşluk Tuşuna Basın").pack(pady=5)
    win.focus_set()
    win.mainloop()