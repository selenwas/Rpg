import tkinter as tk
from town import show_town
from player import Player, save_player

characters = {
    "Warrior": {"STR": 10, "DEX": 5, "HP": 100, "VIT": 8},
    "Mage": {"STR": 3, "DEX": 6, "HP": 60, "VIT": 5, "INT": 12},
    "Archer": {"STR": 5, "DEX": 10, "HP": 80, "VIT": 6},
    "Tank": {"STR": 8, "DEX": 4, "HP": 150, "VIT": 12},
    "Summoner": {"STR": 4, "DEX": 5, "HP": 70, "VIT": 5, "INT": 10}
}

def show_character_screen():
    win = tk.Tk()
    win.title("Karakter Seçimi")
    win.geometry("300x400")
    tk.Label(win, text="Karakter Seç", font=("Arial", 14)).pack(pady=10)

    for name, stats in characters.items():
        def select(n=name, s=stats):
            player = Player(n, s)
            save_player(player)
            win.destroy()
            show_town(player)
        tk.Button(win, text=name, command=select).pack(pady=5)

    win.mainloop()