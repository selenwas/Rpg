import json

class Player:
    def __init__(self, name, stats, inventory=None, level=1, xp=0):
        self.name = name
        self.stats = stats
        self.inventory = inventory or []
        self.level = level
        self.xp = xp

    def to_dict(self):
        return {
            "name": self.name,
            "stats": self.stats,
            "inventory": self.inventory,
            "level": self.level,
            "xp": self.xp
        }

def save_player(player):
    with open("data/player.json", "w") as f:
        json.dump(player.to_dict(), f)

def load_player():
    with open("data/player.json", "r") as f:
        data = json.load(f)
    return Player(data["name"], data["stats"], data["inventory"], data["level"], data["xp"])